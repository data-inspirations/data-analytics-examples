drop table apiCall;
go

create table apiCall (
   querytype varchar(25), 
   urlSuffix1 varchar(50),
   --urlVariable varchar(25),
   urlSuffix2 varchar(50),
   iterative bit,
   queryFile varchar(25),
   queryPath varchar(25),
   queryObject varchar(25),
   processOrder tinyint
);

insert into apiCall (querytype, urlSuffix1, urlSuffix2, iterative, queryFile, queryPath, queryObject, processOrder) 
values ('teams', 'teams', NULL, 0, NULL, NULL, NULL, 1);
insert into apiCall (querytype, urlSuffix1,urlSuffix2, iterative, queryFile, queryPath, queryObject, processOrder) 
values ('games', 'schedule?season=', NULL, 1, NULL, NULL, NULL, 5);
insert into apiCall (querytype, urlSuffix1, urlSuffix2, iterative, queryFile, queryPath, queryObject, processOrder) 
values ('roster', 'teams/', '/roster', 1, 'teams', '$.id', '$.teams', 2);
insert into apiCall (querytype, urlSuffix1, urlSuffix2, iterative, queryFile, queryPath, queryObject, processOrder) 
values ('players', 'people/',  NULL, 1, 'roster', '$.person.id', '$.roster', 3);
insert into apiCall (querytype, urlSuffix1, urlSuffix2, iterative, queryFile, queryPath, queryObject, processOrder) 
values ('playerStatistics', 'teams/', '?hydrate=roster(person(stats(splits=yearByYear)))', 1, 'teams', '$.id', '$.teams', 4);

/*

 convert to expression
 path = E:\Data\                 this is in pkg
 queryType = teams
 queryPath = $.id
 queryObject = $.teams
 */
 /*
SELECT Name,Gender,Company,Email
FROM OPENJSON(@EmployeeDetails, '$.EmployeeDetails.Employee')
WITH(
    Name nvarchar(50) '$.name',
        Gender nvarchar(50) '$.gender',
    Company nvarchar(50) '$.company',
    Email nvarchar(50) '$.email'
)  
 */